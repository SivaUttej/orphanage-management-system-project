$(document).ready(function() {
	$('.js--wp-1').waypoint(function(direction){
		$('.js--wp-1').addClass('animate__animated animate__pulse');
	});
	
	$('.js--wp-4').waypoint(function(direction){
		$('.js--wp-4').addClass('animate__animated animate__pulse');
	});
	
	$('.js--wp-5').waypoint(function(direction){
		$('.js--wp-5').addClass('animate__animated animate__pulse');
	});
	
	$('.js--wp-6').waypoint(function(direction){
		$('.js--wp-6').addClass('animate__animated animate__pulse');
	});
});